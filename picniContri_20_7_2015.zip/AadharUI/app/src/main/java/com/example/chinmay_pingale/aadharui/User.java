package com.example.chinmay_pingale.aadharui;

/**
 * Created by chinmay_pingale on 7/20/2015.
 */
public class User {
    private String user_id;
    private String name;
    private String password;
    boolean selected = false;

    public User(String user_id, String name, boolean selected) {
        this.user_id = user_id;
        this.name = name;
        this.selected = selected;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
