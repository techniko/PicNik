package com.example.chinmay_pingale.aadharui;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Chinmay on 19-07-2015.
 */
public class MyAdapter extends BaseAdapter {
    private static LayoutInflater inflater=null;
    private Activity activity;

    private List<Event> list;


    public MyAdapter(Activity a, List<Event> l) {
        activity = a;
        list=l;
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //imageLoader=new ImageLoader(activity.getApplicationContext());
        activity.setTitle("Events");

    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi=convertView;
        if(convertView==null)
            vi = inflater.inflate(R.layout.item_list, null);

        TextView eventName = (TextView)vi.findViewById(R.id.eventName); // title
        TextView description = (TextView)vi.findViewById(R.id.description); // artist name
        TextView date = (TextView)vi.findViewById(R.id.date); // duration
        ImageView thumb_image=(ImageView)vi.findViewById(R.id.list_image); // thumb image
        //TextView tbar=(TextView)convertView.findViewById(R.id.title_bar);
        ///List<Patient>song = new ArrayList<Patient>();
        //song = data.get(position);

        // Setting all values in listview

            eventName.setText(list.get(position).getEventName());
            description.setText(list.get(position).getDescription());
            date.setText(list.get(position).getDate().getDay()+"/"+list.get(position).getDate().getMonth()+"/"+list.get(position).getDate().getYear());
            thumb_image.setImageDrawable(vi.getContext().getResources().getDrawable(R.drawable.goa2015));


            //tbar.setText("List of Patients");
            //imageLoader.DisplayImage("Url", thumb_image);
            return vi;



    }
}
