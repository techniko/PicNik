package com.example.chinmay.picnicontriui;

import java.util.Date;

/**
 * Created by Chinmay on 19-07-2015.
 */
public class Event {
    private String eventName;
    private Date date;
    private String description;

    public Event(String eventName, Date date, String description) {
        this.eventName = eventName;
        this.date = date;
        this.description = description;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Event{" +
                "eventName='" + eventName + '\'' +
                ", date=" + date +
                ", description='" + description + '\'' +
                '}';
    }
}
