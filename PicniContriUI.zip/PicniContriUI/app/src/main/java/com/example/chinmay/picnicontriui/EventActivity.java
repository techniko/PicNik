package com.example.chinmay.picnicontriui;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class EventActivity extends ActionBarActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);


        ListView list = (ListView) findViewById(R.id.expandableListView);

        List<Event> eventList=new ArrayList<Event>();

        String eventName="Goa";
        String description="Goa Trip 2015";
        Event e1=new Event(eventName, new Date(1,8,2015), description);
         eventName="Matheran";
         description="Monsoon @Matheran";
        Event e2=new Event(eventName, new Date(10,8,2015), description);
         eventName="Lonavala";
         description="Weekend @Lonavala Waterfalls";
        Event e3=new Event(eventName, new Date(25,7,2015), description);

        eventList.add(e1);
        eventList.add(e2);
        eventList.add(e3);
        MyAdapter adapter = new MyAdapter(this, eventList);
        ///list.setItemsCanFocus(false);
        //list.setChoiceMode(ExpandableListView.CHOICE_MODE_MULTIPLE);

        list.setAdapter(adapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_events, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
